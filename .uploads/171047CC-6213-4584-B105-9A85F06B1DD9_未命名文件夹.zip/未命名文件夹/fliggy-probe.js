/**
 * 飞猪 开屏广告 —— 接口探针（只打印，不改任何响应）
 * ------------------------------------------------------------
 * 目的：先确认飞猪到底在哪个接口拉开屏配置、素材 URL 长什么样。
 * 打开本插件后进一次飞猪，然后到 Loon → 日志 里搜「[飞猪探针]」。
 *
 * 看到什么：
 *   - 有命中 + body 里出现 -tps- / imgextra / aps 之类 → 就是这一条，记下 api 名
 *   - 一条都没命中 → 说明 App 走了 SSL Pinning 或者别的域名，看 [飞猪探针] 有没有 host
 *   - body 是乱码/加密串 → MTOP 走了密文，只能改外层或换思路
 */

(() => {
  const url = typeof $request !== 'undefined' ? $request.url : '(no url)';
  const body = typeof $response !== 'undefined' ? $response.body : '';
  const head = (body || '(空)').slice(0, 1200);
  console.log('[飞猪探针] ' + url);
  console.log('[飞猪探针] body=' + head);
  $done({});
})();

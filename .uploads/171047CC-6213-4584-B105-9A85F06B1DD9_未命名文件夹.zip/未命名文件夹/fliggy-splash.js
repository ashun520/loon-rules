/**
 * 飞猪 开屏广告净化（Loon / http-response 脚本）
 * ------------------------------------------------------------
 * 设计原则：
 *   1) 不 reject。空响应/断连会让 App 的开屏流程等不到回调，
 *      表现就是卡在开屏页反复倒计时，或者直接回落本地缓存素材"循环播放"。
 *   2) 只把"广告位"从返回的 JSON 里摘掉，其它字段原样保留，
 *      让 App 拿到一个「结构合法、但没有广告」的响应，走正常的无广告分支。
 *   3) 只删同时具备「素材地址 + 跳转地址」特征的节点，宁可漏删，不误删业务数据。
 *
 * 用法：挂在飞猪的 MTOP 配置类接口上，requires-body = true
 */

const ENABLE_LOG = false; // 调试时改 true，在 Loon 日志里能看删了什么

// 素材类字段名
const ASSET_KEY = /^(img|image|imgurl|imageurl|img_url|image_url|pic|picurl|pic_url|src|mediaurl|media_url|video|videourl|video_url|resourceurl|resource_url|asset|asseturl)$/i;
// 跳转/落地类字段名
const JUMP_KEY = /^(jumpurl|jump_url|targeturl|target_url|landingurl|landing_url|clickurl|click_url|actionurl|action_url|h5url|h5_url|deeplink|scheme|schema|goto|target)$/i;
// 广告位字段名（强特征）
const AD_KEY = /(splash|kaiping|welcome|open_?screen|launch_?ad|startup_?ad|advert|ad_?info|ad_?item|pop_?layer|poplayer|pop_?window|tms_?(splash|ad|resource|advert))/i;

const MAX_DEPTH = 8;

function isObj(v) {
  return v !== null && typeof v === 'object';
}

function hasKeyMatching(o, re) {
  for (const k in o) {
    if (re.test(k)) return true;
  }
  return false;
}

// 一个对象"像广告"：既有素材地址，又有跳转地址
function looksLikeAd(o) {
  if (!isObj(o) || Array.isArray(o)) return false;
  return hasKeyMatching(o, ASSET_KEY) && hasKeyMatching(o, JUMP_KEY);
}

// 子树里（有限深度）是否存在广告节点
function containsAd(node, depth) {
  if (!isObj(node)) return false;
  if (looksLikeAd(node)) return true;
  if (depth <= 0) return false;
  const list = Array.isArray(node) ? node : Object.values(node);
  for (const v of list) {
    if (isObj(v) && containsAd(v, depth - 1)) return true;
  }
  return false;
}

function isEmptyish(o) {
  return isObj(o) && Object.keys(o).length === 0;
}

function clean(node, depth, path) {
  if (!isObj(node) || depth <= 0) return node;

  if (Array.isArray(node)) {
    for (let i = node.length - 1; i >= 0; i--) {
      const v = node[i];
      if (looksLikeAd(v)) {
        if (ENABLE_LOG) console.log('[飞猪] 删除数组广告元素 ' + path + '[' + i + ']');
        node.splice(i, 1);
      } else {
        clean(v, depth - 1, path + '[' + i + ']');
      }
    }
    return node;
  }

  for (const k in node) {
    const v = node[k];
    if (!isObj(v)) continue;

    if (AD_KEY.test(k) && (looksLikeAd(v) || containsAd(v, 3))) {
      // 保留 key，但置空：避免调用方读 undefined 抛异常
      node[k] = Array.isArray(v) ? [] : {};
      if (ENABLE_LOG) console.log('[飞猪] 清空广告位 ' + path + '.' + k);
      continue;
    }

    clean(v, depth - 1, path + '.' + k);
  }
  return node;
}

// MTOP 网关常见结构：{ api, v, ret: [...], data: {...} }，data 里还可能再套一层 JSON 字符串
function cleanWrapper(root) {
  if (!isObj(root) || Array.isArray(root)) return root;

  const handle = (holder, keyName) => {
    const d = holder[keyName];
    if (typeof d === 'string') {
      try {
        const parsed = JSON.parse(d);
        clean(parsed, MAX_DEPTH, keyName);
        holder[keyName] = JSON.stringify(parsed);
        if (ENABLE_LOG) console.log('[飞猪] 二次解析 JSON 字符串完成 ' + keyName);
      } catch (e) {
        if (ENABLE_LOG) console.log('[飞猪] 字符串不是 JSON，跳过 ' + keyName);
      }
    } else if (isObj(d)) {
      clean(d, MAX_DEPTH, keyName);
      if (typeof d.data === 'string') {
        try {
          const parsed = JSON.parse(d.data);
          clean(parsed, MAX_DEPTH, keyName + '.data');
          d.data = JSON.stringify(parsed);
        } catch (e) {}
      }
    }
  };

  handle(root, 'data');
  // 少数接口把业务体放在 result / info 里
  handle(root, 'result');
  handle(root, 'info');
  return root;
}

(() => {
  let body = typeof $response !== 'undefined' ? $response.body : null;
  if (!body) {
    $done({});
    return;
  }

  let root;
  try {
    root = JSON.parse(body);
  } catch (e) {
    // 不是 JSON（可能是加密串或 HTML），无法安全改写，原样放行
    if (ENABLE_LOG) console.log('[飞猪] 响应不是明文 JSON，放行');
    $done({});
    return;
  }

  // 有些接口整体被包成字符串
  if (typeof root === 'string') {
    try {
      root = JSON.parse(root);
    } catch (e) {
      $done({});
      return;
    }
  }

  cleanWrapper(root);
  $done({ body: JSON.stringify(root) });
})();
